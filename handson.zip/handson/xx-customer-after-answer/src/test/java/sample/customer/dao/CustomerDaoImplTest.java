package sample.customer.dao;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import sample.customer.config.DaoConfig;
import sample.customer.config.DbConfig;
import sample.customer.dao.CustomerDao;
import sample.customer.entity.Customer;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes={DbConfig.class, DaoConfig.class})
@Sql({"/sql/table.sql", "/sql/data.sql"})
public class CustomerDaoImplTest {
	
	@Autowired
	CustomerDao dao;

	
	@Test
	public void test_findById() {				
		Customer customer = dao.findById("c001");
		assertEquals("東京太郎", customer.getName());
	}
	
	@Test
	public void test_findAll() {
		List<Customer> customers = dao.findAll();
		assertEquals(3, customers.size());
	}
	
	@Test
	public void test_udpate() {
		
		Customer customer = new Customer();
		customer.setId("c001");
		customer.setName("東京次郎");
		
		int updated = dao.update(customer);
		assertEquals(1, updated);
		
		customer = dao.findById("c001");
		assertEquals("東京次郎", customer.getName());				
	}

}
