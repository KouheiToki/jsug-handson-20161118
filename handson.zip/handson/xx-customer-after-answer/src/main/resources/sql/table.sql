set MODE MySQL;
drop table customer if exists;
create table customer (
	id varchar(50),
	name varchar(100),
	email_address varchar(100),
	birthday date,
	favorite_number int,
	PRIMARY KEY (id)
	
);
