package sample.customer.config;

import org.springframework.context.annotation.ComponentScan;

import sample.customer.dao.CustomerDao;

@ComponentScan(basePackageClasses=CustomerDao.class)
public class DaoConfig {

}
