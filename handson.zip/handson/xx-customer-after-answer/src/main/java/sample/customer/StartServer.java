package sample.customer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Import;

import sample.customer.config.ControllerConfig;
import sample.customer.config.DaoConfig;
import sample.customer.config.DbConfig;
import sample.customer.config.MvcConfig;
import sample.customer.config.ServiceConfig;

@Import({DbConfig.class, MvcConfig.class, ControllerConfig.class, ServiceConfig.class, DaoConfig.class})
@EnableAutoConfiguration
public class StartServer {

	public static void main(String[] args) {
		System.setProperty("server.contextPath", "/customer-after-answer");
		SpringApplication.run(StartServer.class, args);
	}

}
