package sample.customer.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import sample.customer.service.CustomerService;

@ComponentScan(basePackageClasses=CustomerService.class)
@EnableTransactionManagement
public class ServiceConfig {

}
