package sample.customer.entity;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.AssertFalse;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

public class Customer implements Serializable {
	private static final long serialVersionUID = 1L;

	private String id;

	@NotEmpty
	@Size(max = 20)
	private String name;

	@NotEmpty
	@Pattern(regexp = ".+@.+")
	private String emailAddress;

	@NotNull
	@DateTimeFormat(pattern = "yyyy/MM/dd")
	private Date birthday;

	@Max(9)
	@Min(0)
	@NotNull
	private Integer favoriteNumber;

	@AssertFalse(message = "{errors.emailAddress.ng}")
	public boolean isNgEmail() {
		if (emailAddress == null) {
			return false;
		}
		// ドメイン名が「invalid.com」であれば使用不可のアドレスと見なす
		return emailAddress.matches(".*@invalid.com$");
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public Integer getFavoriteNumber() {
		return favoriteNumber;
	}

	public void setFavoriteNumber(Integer favoriteNumber) {
		this.favoriteNumber = favoriteNumber;
	}

}
