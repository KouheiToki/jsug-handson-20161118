package sample.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import sample.customer.dao.CustomerDao;
import sample.customer.entity.Customer;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDao customerDao;
	
	@Override
	@Transactional(readOnly=true)
	public List<Customer> findAll() {
		return customerDao.findAll();
	}

	@Override
	@Transactional(readOnly=true)
	public Customer findById(String id) {
		return customerDao.findById(id);
	}

	@Override
	public void update(Customer customer) {
		int updated = customerDao.update(customer);
		if (updated == 0) {
			throw new RuntimeException("更新できませんでした id="+customer.getId());
		}
	}


}
