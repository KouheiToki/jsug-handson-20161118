package sample.customer.config;

import org.springframework.context.annotation.ComponentScan;

import sample.customer.controller.CustomerShowController;

@ComponentScan(basePackageClasses=CustomerShowController.class)
public class ControllerConfig {

}
