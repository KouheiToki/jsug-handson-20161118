package org.jsug.customer.service;

import java.util.List;

import org.jsug.customer.dao.CustomerDao;
import org.jsug.customer.entity.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDao customerDao;
	
	@Override
	@Transactional(readOnly=true)
	public List<Customer> findAll() {
		return customerDao.findAll();
	}

	@Override
	@Transactional(readOnly=true)
	public Customer findById(String id) {
		return customerDao.findById(id);
	}

	@Override
	public void update(Customer customer) {
		int updated = customerDao.update(customer);
		if (updated == 0) {
			throw new RuntimeException("更新できませんでした id="+customer.getId());
		}
	}


}
