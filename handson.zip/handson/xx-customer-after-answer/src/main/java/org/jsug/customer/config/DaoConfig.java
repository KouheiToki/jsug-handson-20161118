package org.jsug.customer.config;

import org.jsug.customer.dao.CustomerDao;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackageClasses=CustomerDao.class)
public class DaoConfig {

}
