package org.jsug.customer.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.jsug.customer.entity.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class CustomerDaoImpl implements CustomerDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public Customer findById(String id) {
		String sql = "select id, name, email_address, birthday, favorite_number from customer where id=?";
		return jdbcTemplate.queryForObject(sql, new RowMapper<Customer>() {
			@Override
			public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
				Customer customer = new Customer();
				customer.setId(rs.getString("id"));
				customer.setName(rs.getString("name"));
				customer.setEmailAddress(rs.getString("email_address"));
				customer.setBirthday(rs.getDate("birthday"));
				customer.setFavoriteNumber((Integer)rs.getObject("favorite_number"));
				return customer;
			}			
		},id) ;
	}

	@Override
	public List<Customer> findAll() {
		String sql = "select id, name, email_address, birthday, favorite_number from customer";
		return jdbcTemplate.query(sql, new RowMapper<Customer>() {
			@Override
			public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
				Customer customer = new Customer();
				customer.setId(rs.getString("id"));
				customer.setName(rs.getString("name"));
				customer.setEmailAddress(rs.getString("email_address"));
				customer.setBirthday(rs.getDate("birthday"));
				customer.setFavoriteNumber((Integer)rs.getObject("favorite_number"));
				return customer;
			}			
		}) ;
	}

	@Override
	public int update(Customer customer) {
		String sql = "update customer set name=?, email_address=?, birthday=?, favorite_number=? where id=?";
		return jdbcTemplate.update(sql, 
				customer.getName(), 
				customer.getEmailAddress(), 
				customer.getBirthday(), 
				customer.getFavoriteNumber(), 
				customer.getId());		
	}	
}
