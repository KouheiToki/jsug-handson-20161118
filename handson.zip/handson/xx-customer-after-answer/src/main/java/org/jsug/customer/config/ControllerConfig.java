package org.jsug.customer.config;

import org.jsug.customer.controller.CustomerShowController;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackageClasses=CustomerShowController.class)
public class ControllerConfig {

}
