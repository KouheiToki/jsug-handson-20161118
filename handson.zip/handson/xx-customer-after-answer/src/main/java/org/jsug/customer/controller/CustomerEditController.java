package org.jsug.customer.controller;

import org.jsug.customer.entity.Customer;
import org.jsug.customer.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CustomerEditController {

	@Autowired
	private CustomerService customerService;
	
	@RequestMapping(value="/customer/edit", method=RequestMethod.GET)
	public String editForm(@RequestParam("id") String id, Model model) {
		Customer customer = customerService.findById(id);
		model.addAttribute("customer", customer);		
		return "customer/edit";
	}
	
	@RequestMapping(value="/customer/edit", method=RequestMethod.POST)
	public String edit(@Validated Customer customer, BindingResult result, Model model) {
		if (result.hasErrors()) {
			return "customer/edit";
		}
		customerService.update(customer);		
		model.addAttribute("customer", customer);		
		return "customer/edited";
	}
	
}
