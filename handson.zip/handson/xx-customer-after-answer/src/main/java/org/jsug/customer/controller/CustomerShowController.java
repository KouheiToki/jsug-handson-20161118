package org.jsug.customer.controller;

import java.util.List;

import org.jsug.customer.entity.Customer;
import org.jsug.customer.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CustomerShowController {

	@Autowired
	private CustomerService customerService;
	
	@RequestMapping(value="/customer", method=RequestMethod.GET)
	public String list(Model model) {
		List<Customer> customers = customerService.findAll();
		model.addAttribute("customers", customers);		
		return "customer/list";
	}
	
	@RequestMapping(value="/customer/detail", method=RequestMethod.GET)
	public String detail(@RequestParam("id") String id, Model model) {
		Customer customer = customerService.findById(id);
		model.addAttribute("customer", customer);		
		return "customer/detail";
	}
	
}
