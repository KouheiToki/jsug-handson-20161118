package org.jsug.customer.dao;

import java.util.List;

import org.jsug.customer.entity.Customer;

public interface CustomerDao {

	Customer findById(String id);

	List<Customer> findAll();
	
	int update(Customer customer);
	
	
}
