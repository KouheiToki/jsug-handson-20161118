package org.jsug.customer.config;

import org.jsug.customer.service.CustomerService;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@ComponentScan(basePackageClasses=CustomerService.class)
@EnableTransactionManagement
public class ServiceConfig {

}
