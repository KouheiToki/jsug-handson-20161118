package org.jsug.customer;

import org.jsug.customer.config.ControllerConfig;
import org.jsug.customer.config.DaoConfig;
import org.jsug.customer.config.DbConfig;
import org.jsug.customer.config.MvcConfig;
import org.jsug.customer.config.ServiceConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Import;

@Import({DbConfig.class, MvcConfig.class, ControllerConfig.class, ServiceConfig.class, DaoConfig.class})
@EnableAutoConfiguration
public class StartServer {

	public static void main(String[] args) {
		System.setProperty("server.contextPath", "/customer-after-answer");
		SpringApplication.run(StartServer.class, args);
	}

}
