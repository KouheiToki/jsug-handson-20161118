insert into customer (id,name,email_address,birthday,favorite_number) values ('c001','東京太郎','taro@foo.com','1976-11-11',5);
insert into customer (id,name,email_address,birthday,favorite_number) values ('c002','大阪花子','hanako@foo.com','1976-11-11',5);
insert into customer (id,name,email_address,birthday,favorite_number) values ('c003','神奈川次郎','jiro@foo.com','1976-11-11',5);