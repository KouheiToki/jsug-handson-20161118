package org.jsug.customer.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jsug.customer.entity.Customer;
import org.jsug.customer.service.CustomerService;
import org.jsug.customer.service.CustomerServiceImpl;

public class CustomerListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	private CustomerService customerService;
	 
	@Override
	public void init() throws ServletException {
		customerService = new CustomerServiceImpl();
	}


	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
				
		List<Customer> customers = customerService.findAll();
		req.setAttribute("customers", customers);
		
		getServletContext().getRequestDispatcher("/WEB-INF/views/customer/list.jsp").forward(req, resp);
		
	}

	
	
}
