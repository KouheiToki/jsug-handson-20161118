package org.jsug.customer.service;

import java.util.List;

import org.jsug.customer.entity.Customer;

public interface CustomerService {
	
    public List<Customer> findAll();
    
    public Customer findById(String id);
    
    public void update(Customer customer);
    
}
