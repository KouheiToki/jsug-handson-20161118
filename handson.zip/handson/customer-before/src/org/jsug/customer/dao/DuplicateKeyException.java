package org.jsug.customer.dao;

public class DuplicateKeyException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	
	public DuplicateKeyException(String msg) {
		super(msg);
	}
	public DuplicateKeyException(String msg, Throwable e) {
		super(msg, e);
	}
}
