package org.jsug.customer.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.jsug.customer.entity.Customer;

public class CustomerDaoImpl implements CustomerDao {

	@Override
	public List<Customer> findAll(Connection con) throws SQLException {		
		String sql = "select id, name, email_address, birthday, favorite_number from customer";
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			List<Customer> list = new ArrayList<>();
			while (rs.next()) {
				Customer customer = new Customer();
				customer.setId(rs.getString("id"));
				customer.setName(rs.getString("name"));
				customer.setBirthday(rs.getDate("birthday"));
				customer.setEmailAddress(rs.getString("email_address"));
				customer.setFavoriteNumber((Integer)rs.getObject("favorite_number"));
				list.add(customer);
			}
			return list;
		} finally {
			if (ps!=null){ps.close();}
			if (rs!=null){rs.close();}			
		}
	}



	@Override
	public int update(Connection con, Customer customer) throws SQLException {
		String sql = "update customer set name=?, email_address=?, birthday=?, favorite_number=? where id=?";
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, customer.getName());
			ps.setString(2, customer.getEmailAddress());
			if (customer.getBirthday() != null) {
				ps.setDate(3, new java.sql.Date(customer.getBirthday().getTime()));
			} else {
				ps.setDate(3, null);
			}
			ps.setObject(4, customer.getFavoriteNumber());
			ps.setString(5, customer.getId());
			return ps.executeUpdate();
		} finally {
			if (ps != null) {ps.close();}
		}		
	}
	
	@Override
	public Customer findById(Connection con, String id) throws SQLException {
		String sql = "select id, name, email_address, birthday, favorite_number from customer where id=?";
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();
			if (rs.next()) {
				Customer customer = new Customer();
				customer.setId(rs.getString("id"));
				customer.setName(rs.getString("name"));
				customer.setBirthday(rs.getDate("birthday"));
				customer.setEmailAddress(rs.getString("email_address"));
				customer.setFavoriteNumber((Integer)rs.getObject("favorite_number"));
				return customer;
			} else {
				return null;
			}
		} finally {
			if (ps!=null){ps.close();}
			if (rs!=null){rs.close();}
		}
	}

}
