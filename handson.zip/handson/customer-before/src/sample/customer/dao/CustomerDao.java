package sample.customer.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import sample.customer.entity.Customer;

public interface CustomerDao {

	Customer findById(Connection con, String id) throws SQLException;

	List<Customer> findAll(Connection con) throws SQLException;
	
	int update(Connection con, Customer customer) throws SQLException;
	
	
}
