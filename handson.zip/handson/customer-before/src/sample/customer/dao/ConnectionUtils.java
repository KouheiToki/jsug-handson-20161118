package sample.customer.dao;

import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.SQLException;

import org.h2.jdbcx.JdbcConnectionPool;
import org.h2.tools.RunScript;

public class ConnectionUtils {

	private static JdbcConnectionPool pool;
	static {
		 JdbcConnectionPool cp = JdbcConnectionPool.create(
	             "jdbc:h2:mem:MODE=MySQL", "sa", "");
		 
		try {
			Connection con = cp.getConnection();
			RunScript.execute(con, new InputStreamReader(ConnectionUtils.class.getResourceAsStream("/sql/table.sql")));
			RunScript.execute(con, new InputStreamReader(ConnectionUtils.class.getResourceAsStream("/sql/data.sql")));
			con.close();			
		} catch (SQLException e) {
			throw new RuntimeException("初期処理でエラー", e);
		}
		pool = cp;
	}
	
	public static Connection getConnection() throws SQLException {
		return pool.getConnection();
	}
	
}
