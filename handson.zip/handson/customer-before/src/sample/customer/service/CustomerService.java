package sample.customer.service;

import java.util.List;

import sample.customer.entity.Customer;

public interface CustomerService {
	
    public List<Customer> findAll();
    
    public Customer findById(String id);
    
    public void update(Customer customer);
    
}
