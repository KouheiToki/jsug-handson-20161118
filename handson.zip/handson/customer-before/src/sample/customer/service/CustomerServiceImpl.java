package sample.customer.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import sample.customer.dao.ConnectionUtils;
import sample.customer.dao.CustomerDao;
import sample.customer.dao.CustomerDaoImpl;
import sample.customer.entity.Customer;

public class CustomerServiceImpl implements CustomerService {

	private CustomerDao customerDao;
		
	public CustomerServiceImpl() {
		customerDao = new CustomerDaoImpl();
	}
	
	public List<Customer> findAll() {
		Connection con = null;
		try {
			con = ConnectionUtils.getConnection();
			con.setReadOnly(true);
			return customerDao.findAll(con);
		} catch (SQLException e) {
			throw new RuntimeException("システムエラー", e);
		} finally {
			try {
				if (con!=null) {con.close();}
			} catch (SQLException e) {
				throw new RuntimeException("システムエラー", e);
			}
		}
	}

	@Override
	public Customer findById(String id) {
		Connection con = null;
		try {
			con = ConnectionUtils.getConnection();
			con.setReadOnly(true);
			return customerDao.findById(con, id);
		} catch (SQLException e) {
			throw new RuntimeException("システムエラー", e);
		} finally {
			try {
				if (con!=null) {con.close();}
			} catch (SQLException e) {
				throw new RuntimeException("システムエラー", e);
			}
		}
	}


	@Override
	public void update(Customer customer) {
		Connection con = null;
		try {
			con = ConnectionUtils.getConnection();
			con.setAutoCommit(false);
			int updated = customerDao.update(con, customer);
			if (updated == 0) {
				throw new RuntimeException("更新できませんでした id="+customer.getId());
			}
			con.commit();
		} catch (SQLException e) {
			throw new RuntimeException("システムエラー", e);
		} finally {
			try {
				if (con!=null) {con.rollback();con.close();}
			} catch (SQLException e) {
				throw new RuntimeException("システムエラー", e);
			}
		}		
	}

}
