package sample.customer.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sample.customer.entity.Customer;
import sample.customer.service.CustomerService;
import sample.customer.service.CustomerServiceImpl;

public class CustomerDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private CustomerService customerService;
	 
	@Override
	public void init() throws ServletException {
		customerService = new CustomerServiceImpl();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		Customer customer = customerService.findById(req.getParameter("id"));		
		req.setAttribute("customer", customer);
		
		getServletContext().getRequestDispatcher("/WEB-INF/views/customer/detail.jsp").forward(req, resp);
		
	}

	
	
}
