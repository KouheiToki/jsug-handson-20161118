package sample.customer.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sample.customer.entity.Customer;
import sample.customer.service.CustomerService;
import sample.customer.service.CustomerServiceImpl;

public class CustomerEditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private CustomerService customerService;
	 
	@Override
	public void init() throws ServletException {
		customerService = new CustomerServiceImpl();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		Customer customer = customerService.findById(req.getParameter("id"));		
		req.setAttribute("customer", customer);
		
		getServletContext().getRequestDispatcher("/WEB-INF/views/customer/edit.jsp").forward(req, resp);
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		req.setCharacterEncoding("UTF-8");
		
		String id = req.getParameter("id");
		String name = req.getParameter("name");
		String emailAddress = req.getParameter("emailAddress");
		String birthdayStr = req.getParameter("birthday");
		String favoriteNumberStr = req.getParameter("favoriteNumber");
		
		Customer customer = new Customer();
		customer.setId(id);
		
		Map<String, String> errMap = new HashMap<>();
		if (name == null || name.equals("")) {
			errMap.put("error_name", "名前は必須です");
		} else {
			if (id.length() > 20) {
				errMap.put("error_name", "名前は20文字以内にしてください");
			}
		}
		customer.setName(name);

		if (emailAddress == null || emailAddress.equals("")) {
			errMap.put("error_emailAddress", "EMAILは必須です");
		} else {
			if (!emailAddress.matches(".+@.+")) {
				errMap.put("error_emailAddress", "EMAILの形式が不正です");
			}
			if (emailAddress.matches(".*@invalid.com$")) {
				errMap.put("error_emailAddress", "このアドレスは利用できません");
			}
		}
		customer.setEmailAddress(emailAddress);
		
		Date birthday = null;
		if (birthdayStr == null || birthdayStr.equals("")) {
			errMap.put("error_birthday", "誕生日は必須です");
		} else {
			try {
				SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd");
				df.setLenient(false);
				birthday = df.parse(birthdayStr);
			} catch (ParseException e) {
				errMap.put("error_birthday", "書式が不正です");
			}
		}
		customer.setBirthday(birthday);
		
		Integer favoriteNumber = null;
		if (favoriteNumberStr == null || favoriteNumberStr.equals("")) {
			errMap.put("error_favoriteNumber", "好きな数字は必須です");
		} else {
			try {
				favoriteNumber = Integer.parseInt(favoriteNumberStr);
				
				if (favoriteNumber < 0 || favoriteNumber > 9) {
					errMap.put("error_favoriteNumber", "0~9を入力してください");
				}				
			} catch (NumberFormatException e) {
				errMap.put("error_favoriteNumber", "書式が不正です");
			}
		}
		customer.setFavoriteNumber(favoriteNumber);

		if (errMap.size() > 0) {
			for (String key : errMap.keySet()) {
				req.setAttribute(key, errMap.get(key));
			}
			req.setAttribute("customer", customer);
			getServletContext().getRequestDispatcher("/WEB-INF/views/customer/edit.jsp").forward(req, resp);
			return;
		}
 		
		customerService.update(customer);
		
		req.setAttribute("customer", customer);
		getServletContext().getRequestDispatcher("/WEB-INF/views/customer/edited.jsp").forward(req, resp);

		
	}

	
	
	
	
}
