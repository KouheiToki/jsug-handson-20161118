package org.jsug.customer.service;

import static org.junit.Assert.*;

import java.io.InputStreamReader;
import java.sql.Connection;
import java.util.List;

import org.h2.tools.RunScript;
import org.jsug.customer.dao.ConnectionUtils;
import org.jsug.customer.entity.Customer;
import org.junit.Before;
import org.junit.Test;

public class CustomerServiceImplTest {

	CustomerService service;
	Connection con;
	
	@Before
	public void setup() throws Exception {
		service = new CustomerServiceImpl();
		con = ConnectionUtils.getConnection();
		RunScript.execute(con, new InputStreamReader(getClass().getResourceAsStream("/sql/table.sql")));		
		RunScript.execute(con, new InputStreamReader(getClass().getResourceAsStream("/sql/data.sql")));		
		con.close();
	}
	
	@Test
	public void test_findById() {
		Customer customer = service.findById("c001");
		assertEquals("東京太郎", customer.getName());
	}

	@Test
	public void test_findAll() {
		List<Customer> list = service.findAll();
		assertEquals(3, list.size());
	}
	
	@Test
	public void test_update() {
		Customer customer = new Customer();
		customer.setId("c001");
		customer.setName("東京次郎");

		service.update(customer);
		
		customer = service.findById("c001");
		assertEquals("東京次郎", customer.getName());		
	}
	
}
