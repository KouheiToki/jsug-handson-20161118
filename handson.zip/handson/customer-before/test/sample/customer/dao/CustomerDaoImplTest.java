package sample.customer.dao;

import static org.junit.Assert.*;

import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.h2.tools.RunScript;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import sample.customer.dao.ConnectionUtils;
import sample.customer.dao.CustomerDao;
import sample.customer.dao.CustomerDaoImpl;
import sample.customer.entity.Customer;

public class CustomerDaoImplTest {

	CustomerDao dao;
	Connection con;

	@Before
	public void setup() throws Exception {
		dao = new CustomerDaoImpl();		
		con = ConnectionUtils.getConnection();
		RunScript.execute(con, new InputStreamReader(getClass().getResourceAsStream("/sql/table.sql")));
		RunScript.execute(con, new InputStreamReader(getClass().getResourceAsStream("/sql/data.sql")));
	}
	
	@After
	public void teardown() throws Exception {
		con.close();
	}
	
	@Test
	public void test_findById() throws SQLException {
		Customer customer  = dao.findById(con, "c001");
		assertEquals("東京太郎", customer.getName());		
	}

	@Test
	public void test_findAll() throws Exception {
		List<Customer> list = dao.findAll(con);
		assertEquals(3, list.size());
	}
	
	
	@Test
	public void test_update() throws Exception {
		Customer customer = new Customer();
		customer.setId("c001");
		customer.setName("東京次郎");

		dao.update(con, customer);
		
		customer = dao.findById(con, "c001");
		assertEquals("東京次郎", customer.getName());
	}
	
}
